# Change Log

## [v0.0.6] 

- Migrate Table `Stats` - define new column
- Inspect the new table structure & data

## [v0.0.5] 

- Added New Table: `Stats`
- Populate the table using `Flask CLI`

## [v0.0.4] 

- Configuration Update

## [v0.0.3] 

- Integrate SqlAlchemy

## [v0.0.2] 

- Added dependencies: `flask_sqlalchemy`, `flask_migrate`

## [v0.0.1] 

- No feature coded
- Update README (minor)
